import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Heart, 
  Brain, 
  Activity, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  BookOpen,
  Video,
  Users
} from 'lucide-react';

const HealthInfo = () => {
  const [activeTab, setActiveTab] = useState('benefits');

  const benefits = [
    {
      icon: <Heart className="w-6 h-6 text-red-500" />,
      title: '改善前列腺健康',
      description: '定期提肛运动可以增强盆底肌肉，改善前列腺血液循环，预防前列腺疾病。',
      evidence: '临床研究证实'
    },
    {
      icon: <Activity className="w-6 h-6 text-blue-500" />,
      title: '增强性功能',
      description: '强化盆底肌肉群，提高性生活质量，增强男性自信心。',
      evidence: '医学认证'
    },
    {
      icon: <Brain className="w-6 h-6 text-purple-500" />,
      title: '缓解压力',
      description: '规律的运动有助于释放内啡肽，减轻工作压力，改善心理健康。',
      evidence: '心理学研究'
    },
    {
      icon: <CheckCircle className="w-6 h-6 text-green-500" />,
      title: '预防尿失禁',
      description: '加强盆底肌肉控制力，有效预防和改善尿失禁问题。',
      evidence: '康复医学'
    }
  ];

  const techniques = [
    {
      step: 1,
      title: '准备阶段',
      description: '找一个舒适的位置，可以坐着、躺着或站着。保持自然呼吸，放松身体。',
      duration: '30秒',
      tips: ['选择安静的环境', '穿着宽松的衣物', '排空膀胱']
    },
    {
      step: 2,
      title: '收缩阶段',
      description: '缓慢收紧肛门周围的肌肉，想象正在阻止排气或排尿。',
      duration: '3-5秒',
      tips: ['不要屏住呼吸', '避免收紧臀部', '专注于肛门肌肉']
    },
    {
      step: 3,
      title: '保持阶段',
      description: '维持收缩状态，保持正常呼吸，感受肌肉的紧张感。',
      duration: '3-5秒',
      tips: ['保持呼吸顺畅', '集中注意力', '避免过度用力']
    },
    {
      step: 4,
      title: '放松阶段',
      description: '缓慢放松肌肉，让肛门回到自然状态，休息片刻。',
      duration: '3-5秒',
      tips: ['完全放松', '感受肌肉恢复', '准备下一次收缩']
    }
  ];

  const schedule = [
    {
      level: '初学者',
      frequency: '每天2-3次',
      sets: '每次10-15个',
      duration: '持续2-4周',
      color: 'bg-green-100 text-green-800'
    },
    {
      level: '进阶者',
      frequency: '每天3-4次',
      sets: '每次15-20个',
      duration: '持续4-8周',
      color: 'bg-blue-100 text-blue-800'
    },
    {
      level: '高级者',
      frequency: '每天4-5次',
      sets: '每次20-30个',
      duration: '长期坚持',
      color: 'bg-purple-100 text-purple-800'
    }
  ];

  const myths = [
    {
      myth: '提肛运动只对老年人有用',
      truth: '任何年龄的男性都可以从提肛运动中受益，预防胜于治疗。',
      icon: <AlertCircle className="w-5 h-5 text-red-500" />
    },
    {
      myth: '运动强度越大效果越好',
      truth: '适度的强度和正确的技巧比过度用力更重要。',
      icon: <AlertCircle className="w-5 h-5 text-orange-500" />
    },
    {
      myth: '短期内就能看到明显效果',
      truth: '需要坚持4-6周才能感受到明显的改善。',
      icon: <Clock className="w-5 h-5 text-blue-500" />
    },
    {
      myth: '只有有问题的人才需要做',
      truth: '健康的人群也应该定期锻炼，作为预防保健措施。',
      icon: <Heart className="w-5 h-5 text-green-500" />
    }
  ];

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gradient mb-4">健康知识中心</h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          了解提肛运动的科学原理和正确方法，让健康成为一种生活方式
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="benefits" className="flex items-center space-x-2">
            <Heart className="w-4 h-4" />
            <span>健康益处</span>
          </TabsTrigger>
          <TabsTrigger value="techniques" className="flex items-center space-x-2">
            <BookOpen className="w-4 h-4" />
            <span>运动技巧</span>
          </TabsTrigger>
          <TabsTrigger value="schedule" className="flex items-center space-x-2">
            <Clock className="w-4 h-4" />
            <span>训练计划</span>
          </TabsTrigger>
          <TabsTrigger value="myths" className="flex items-center space-x-2">
            <AlertCircle className="w-4 h-4" />
            <span>常见误区</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="benefits" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {benefits.map((benefit, index) => (
              <Card key={index} className="card-hover">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      {benefit.icon}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">{benefit.title}</h3>
                      <p className="text-gray-600 mb-3">{benefit.description}</p>
                      <Badge variant="outline" className="text-xs">
                        {benefit.evidence}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="techniques" className="mt-6">
          <div className="space-y-6">
            {techniques.map((technique, index) => (
              <Card key={index} className="card-hover">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center font-bold">
                      {technique.step}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-lg font-semibold">{technique.title}</h3>
                        <Badge variant="secondary">{technique.duration}</Badge>
                      </div>
                      <p className="text-gray-600 mb-3">{technique.description}</p>
                      <div className="flex flex-wrap gap-2">
                        {technique.tips.map((tip, tipIndex) => (
                          <Badge key={tipIndex} variant="outline" className="text-xs">
                            {tip}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="schedule" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {schedule.map((plan, index) => (
              <Card key={index} className="card-hover">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{plan.level}</span>
                    <Badge className={plan.color}>{plan.level}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">频率：</span>
                      <span className="font-medium">{plan.frequency}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">组数：</span>
                      <span className="font-medium">{plan.sets}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">周期：</span>
                      <span className="font-medium">{plan.duration}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <Card className="mt-6 bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Video className="w-6 h-6 text-blue-500" />
                <h3 className="text-lg font-semibold">专业指导视频</h3>
              </div>
              <p className="text-gray-600 mb-4">
                观看专业医师示范的提肛运动标准动作，确保您的锻炼方法正确有效。
              </p>
              <div className="bg-gray-200 rounded-lg h-32 flex items-center justify-center">
                <div className="text-center">
                  <Video className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500">视频即将上线</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="myths" className="mt-6">
          <div className="space-y-4">
            {myths.map((item, index) => (
              <Card key={index} className="card-hover">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      {item.icon}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2 text-red-600">
                        ❌ 误区：{item.myth}
                      </h3>
                      <p className="text-gray-600">
                        ✅ 事实：{item.truth}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="mt-6 bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Users className="w-6 h-6 text-green-500" />
                <h3 className="text-lg font-semibold">专家建议</h3>
              </div>
              <div className="space-y-3 text-gray-600">
                <p>• 开始前咨询医生，特别是有前列腺疾病史的患者</p>
                <p>• 循序渐进，不要急于求成</p>
                <p>• 保持规律性，每天固定时间练习</p>
                <p>• 结合其他健康生活方式，如适量运动和均衡饮食</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default HealthInfo;


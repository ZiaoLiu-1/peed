import React, { useState } from 'react';
import Header from './components/Header';
import TigangButton from './components/TigangButton';
import Community from './components/Community';
import HealthInfo from './components/HealthInfo';
import { Button } from './components/ui/button';
import { Card, CardContent } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { 
  Home, 
  BarChart3, 
  Users, 
  BookOpen, 
  Sparkles,
  ArrowRight,
  Star,
  TrendingUp
} from 'lucide-react';
import './App.css';

function App() {
  const [activeSection, setActiveSection] = useState('home');

  const navigationItems = [
    { id: 'home', label: '首页', icon: Home },
    { id: 'stats', label: '统计', icon: BarChart3 },
    { id: 'community', label: '社区', icon: Users },
    { id: 'health', label: '健康知识', icon: BookOpen },
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'home':
        return <HomeSection />;
      case 'stats':
        return <StatsSection />;
      case 'community':
        return <Community />;
      case 'health':
        return <HealthInfo />;
      default:
        return <HomeSection />;
    }
  };

  const HomeSection = () => (
    <div className="min-h-screen">
      {/* Hero区域 */}
      <section className="hero-background py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="floating-animation mb-8">
            <img 
              src="/src/assets/tigang-logo-v2.png" 
              alt="提肛Logo" 
              className="w-24 h-24 mx-auto rounded-full shadow-lg"
            />
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold text-gradient mb-6">
            提肛
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-600 mb-4">
            健康币圈Meme项目
          </p>
          
          <p className="text-lg text-gray-500 mb-8 max-w-2xl mx-auto">
            通过有趣的币圈文化形式，提醒男性关注前列腺健康，让健康成为一种时尚的生活方式
          </p>

          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <Badge variant="secondary" className="text-sm px-4 py-2">
              <Sparkles className="w-4 h-4 mr-2" />
              创新健康理念
            </Badge>
            <Badge variant="secondary" className="text-sm px-4 py-2">
              <TrendingUp className="w-4 h-4 mr-2" />
              币圈Meme文化
            </Badge>
            <Badge variant="secondary" className="text-sm px-4 py-2">
              <Star className="w-4 h-4 mr-2" />
              社区驱动
            </Badge>
          </div>

          <Button 
            size="lg" 
            className="tigang-gradient text-white px-8 py-3 text-lg"
            onClick={() => setActiveSection('home')}
          >
            开始健康之旅
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </section>

      {/* 主要功能区域 */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">开始你的提肛之旅</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              每天几分钟，让健康成为习惯。加入我们的社区，与志同道合的朋友一起追求健康生活。
            </p>
          </div>

          <TigangButton />
        </div>
      </section>

      {/* 特色功能 */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">为什么选择提肛？</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="card-hover text-center p-6">
              <CardContent>
                <div className="w-16 h-16 tigang-gradient rounded-full flex items-center justify-center mx-auto mb-4">
                  <BarChart3 className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-3">科学追踪</h3>
                <p className="text-gray-600">
                  精确记录每日运动数据，可视化展示健康进步，让坚持变得更有动力。
                </p>
              </CardContent>
            </Card>

            <Card className="card-hover text-center p-6">
              <CardContent>
                <div className="w-16 h-16 tigang-gradient rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-3">社区互动</h3>
                <p className="text-gray-600">
                  与全球用户一起打卡，分享健康心得，在社交中找到坚持的力量。
                </p>
              </CardContent>
            </Card>

            <Card className="card-hover text-center p-6">
              <CardContent>
                <div className="w-16 h-16 tigang-gradient rounded-full flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-3">专业指导</h3>
                <p className="text-gray-600">
                  基于医学研究的运动指导，确保每一次锻炼都科学有效。
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA区域 */}
      <section className="py-16 px-4 tigang-gradient">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h2 className="text-3xl font-bold mb-4">加入提肛社区</h2>
          <p className="text-xl mb-8 opacity-90">
            与数千名用户一起，让健康成为一种生活方式
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              variant="secondary" 
              size="lg"
              onClick={() => setActiveSection('community')}
            >
              查看社区
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="bg-white/10 border-white/30 text-white hover:bg-white/20"
              onClick={() => setActiveSection('health')}
            >
              学习健康知识
            </Button>
          </div>
        </div>
      </section>
    </div>
  );

  const StatsSection = () => (
    <div className="min-h-screen p-6">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-8">我的统计数据</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="text-center p-6">
            <CardContent>
              <div className="text-3xl font-bold text-gradient mb-2">156</div>
              <div className="text-gray-600">总完成次数</div>
            </CardContent>
          </Card>
          
          <Card className="text-center p-6">
            <CardContent>
              <div className="text-3xl font-bold text-gradient mb-2">7</div>
              <div className="text-gray-600">连续天数</div>
            </CardContent>
          </Card>
          
          <Card className="text-center p-6">
            <CardContent>
              <div className="text-3xl font-bold text-gradient mb-2">23</div>
              <div className="text-gray-600">总运动时长(分)</div>
            </CardContent>
          </Card>
          
          <Card className="text-center p-6">
            <CardContent>
              <div className="text-3xl font-bold text-gradient mb-2">15</div>
              <div className="text-gray-600">社区排名</div>
            </CardContent>
          </Card>
        </div>

        <Card className="p-6">
          <h3 className="text-xl font-semibold mb-4">本周进度</h3>
          <div className="space-y-3">
            {['周一', '周二', '周三', '周四', '周五', '周六', '周日'].map((day, index) => (
              <div key={day} className="flex items-center justify-between">
                <span className="text-gray-600">{day}</span>
                <div className="flex items-center space-x-2">
                  <div className="w-32 bg-gray-200 rounded-full h-2">
                    <div 
                      className="tigang-gradient h-2 rounded-full"
                      style={{ width: `${Math.random() * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-sm text-gray-500">{Math.floor(Math.random() * 25)}/20</span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* 导航标签 */}
      <nav className="sticky top-16 bg-white/90 backdrop-blur-md border-b border-gray-200 z-40">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex space-x-8 overflow-x-auto">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`
                    flex items-center space-x-2 py-4 px-2 border-b-2 transition-colors whitespace-nowrap
                    ${activeSection === item.id 
                      ? 'border-primary text-primary' 
                      : 'border-transparent text-gray-600 hover:text-gray-800'
                    }
                  `}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* 主要内容区域 */}
      <main className="fade-in">
        {renderContent()}
      </main>

      {/* 底部 */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <img 
              src="/src/assets/tigang-logo-v2.png" 
              alt="提肛Logo" 
              className="w-8 h-8 rounded-full"
            />
            <span className="text-xl font-bold">提肛</span>
          </div>
          <p className="text-gray-400 mb-6">
            让健康成为一种时尚的生活方式
          </p>
          <div className="flex justify-center space-x-6 text-sm text-gray-400">
            <a href="#" className="hover:text-white transition-colors">关于我们</a>
            <a href="#" className="hover:text-white transition-colors">隐私政策</a>
            <a href="#" className="hover:text-white transition-colors">使用条款</a>
            <a href="#" className="hover:text-white transition-colors">联系我们</a>
          </div>
          <div className="mt-6 pt-6 border-t border-gray-800 text-xs text-gray-500">
            © 2024 提肛项目. 保留所有权利.
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;


import React from 'react';
import { Button } from './ui/button';
import { Wallet, Twitter, Settings } from 'lucide-react';

const Header = () => {
  return (
    <header className="w-full bg-white/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo区域 */}
        <div className="flex items-center space-x-3">
          <img 
            src="/src/assets/tigang-logo-v2.png" 
            alt="提肛Logo" 
            className="w-10 h-10 rounded-full"
          />
          <div>
            <h1 className="text-xl font-bold text-gradient">提肛</h1>
            <p className="text-xs text-gray-500">健康币圈Meme项目</p>
          </div>
        </div>

        {/* 导航菜单 */}
        <nav className="hidden md:flex items-center space-x-6">
          <a href="#home" className="text-gray-600 hover:text-primary transition-colors">
            首页
          </a>
          <a href="#stats" className="text-gray-600 hover:text-primary transition-colors">
            统计
          </a>
          <a href="#community" className="text-gray-600 hover:text-primary transition-colors">
            社区
          </a>
          <a href="#health" className="text-gray-600 hover:text-primary transition-colors">
            健康知识
          </a>
        </nav>

        {/* 操作按钮 */}
        <div className="flex items-center space-x-3">
          <Button 
            variant="outline" 
            size="sm"
            className="hidden sm:flex items-center space-x-2"
          >
            <Twitter className="w-4 h-4" />
            <span>绑定推特</span>
          </Button>
          
          <Button 
            variant="outline" 
            size="sm"
            className="items-center space-x-2"
          >
            <Wallet className="w-4 h-4" />
            <span className="hidden sm:inline">连接钱包</span>
          </Button>

          <Button variant="ghost" size="sm">
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;


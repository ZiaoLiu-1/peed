import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Heart, MessageCircle, Repeat2, ExternalLink } from 'lucide-react';
import { communityAPI } from '../services/api';

const Community = () => {
  const [todayUsers, setTodayUsers] = useState([]);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [postsLoading, setPostsLoading] = useState(false);

  useEffect(() => {
    loadTodayUsers();
    loadCommunityPosts();
  }, []);

  const loadTodayUsers = async () => {
    try {
      setLoading(true);
      const response = await communityAPI.getTodayUsers();
      if (response.success) {
        setTodayUsers(response.data);
      }
    } catch (error) {
      console.error('Failed to load today users:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadCommunityPosts = async () => {
    try {
      setPostsLoading(true);
      const response = await communityAPI.getPosts();
      if (response.success) {
        setPosts(response.data);
      }
    } catch (error) {
      console.error('Failed to load community posts:', error);
    } finally {
      setPostsLoading(false);
    }
  };

  const handleLike = async (postId) => {
    // 模拟点赞功能
    setPosts(prevPosts => 
      prevPosts.map(post => 
        post.id === postId 
          ? { ...post, likes_count: post.likes_count + 1 }
          : post
      )
    );
  };

  const handleRetweet = async (postId) => {
    // 模拟转发功能
    setPosts(prevPosts => 
      prevPosts.map(post => 
        post.id === postId 
          ? { ...post, retweets_count: post.retweets_count + 1 }
          : post
      )
    );
  };

  return (
    <div className="space-y-8 p-6">
      {/* 今日完成用户 */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <span className="mr-2">🏆</span>
          今日完成用户
        </h2>
        
        {loading ? (
          <div className="flex justify-center py-8">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {todayUsers.map((user) => (
              <div key={user.id} className="text-center p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors">
                <div className="text-2xl mb-2">{user.avatar_emoji}</div>
                <div className="font-medium text-sm">{user.username}</div>
                <div className="text-xs text-gray-500 mt-1">
                  {user.today_count}次 · {user.today_time}分钟
                </div>
                {user.is_verified && (
                  <div className="text-xs text-blue-500 mt-1">✓ 已验证</div>
                )}
                {user.goal_achieved && (
                  <div className="text-xs text-green-500 mt-1">🎯 达成目标</div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 社区动态 */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <span className="mr-2">💬</span>
          社区动态
        </h2>
        
        {postsLoading ? (
          <div className="flex justify-center py-8">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map((post) => (
              <div key={post.id} className="border-b border-gray-100 pb-4 last:border-b-0">
                <div className="flex items-start space-x-3">
                  <div className="text-2xl">{post.avatar_emoji}</div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="font-medium">{post.username}</span>
                      {post.is_verified && (
                        <span className="text-blue-500 text-sm">✓</span>
                      )}
                      <span className="text-gray-500 text-sm">{post.timestamp}</span>
                    </div>
                    <p className="text-gray-800 mb-3">{post.content}</p>
                    
                    {/* 互动按钮 */}
                    <div className="flex items-center space-x-6 text-gray-500">
                      <button 
                        onClick={() => handleLike(post.id)}
                        className="flex items-center space-x-1 hover:text-red-500 transition-colors"
                      >
                        <Heart className="w-4 h-4" />
                        <span className="text-sm">{post.likes_count}</span>
                      </button>
                      
                      <button 
                        onClick={() => handleRetweet(post.id)}
                        className="flex items-center space-x-1 hover:text-green-500 transition-colors"
                      >
                        <Repeat2 className="w-4 h-4" />
                        <span className="text-sm">{post.retweets_count}</span>
                      </button>
                      
                      <button className="flex items-center space-x-1 hover:text-blue-500 transition-colors">
                        <MessageCircle className="w-4 h-4" />
                        <span className="text-sm">回复</span>
                      </button>
                      
                      {post.twitter_post_id && (
                        <button className="flex items-center space-x-1 hover:text-blue-500 transition-colors">
                          <ExternalLink className="w-4 h-4" />
                          <span className="text-sm">查看推文</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        
        <div className="mt-6 text-center">
          <Button 
            variant="outline" 
            onClick={loadCommunityPosts}
            disabled={postsLoading}
          >
            查看更多动态
          </Button>
        </div>
      </div>

      {/* 月度排行榜 */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <span className="mr-2">🏅</span>
          月度排行榜
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {[
            { rank: 1, name: '@月度冠军', score: 650, emoji: '🥇', badge: '👑' },
            { rank: 2, name: '@银牌选手', score: 580, emoji: '🥈', badge: '🥈' },
            { rank: 3, name: '@铜牌得主', score: 520, emoji: '🥉', badge: '🥉' },
            { rank: 4, name: '@努力追赶', score: 480, emoji: '⭐', badge: '⭐' },
            { rank: 5, name: '@新星崛起', score: 420, emoji: '🌟', badge: '🌟' }
          ].map((user) => (
            <div key={user.rank} className="text-center p-4 rounded-lg bg-gradient-to-b from-gray-50 to-gray-100">
              <div className="text-3xl mb-2">{user.badge}</div>
              <div className="font-medium text-sm">{user.name}</div>
              <div className="text-lg font-bold text-gradient mt-1">{user.score}</div>
              <div className="text-xs text-gray-500">总次数</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Community;


import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Play, Pause, RotateCcw } from 'lucide-react';
import { exerciseAPI, statsAPI } from '../services/api';

const TigangButton = () => {
  const [isExercising, setIsExercising] = useState(false);
  const [currentPhase, setCurrentPhase] = useState('ready'); // ready, contract, hold, relax
  const [timer, setTimer] = useState(0);
  const [todayCount, setTodayCount] = useState(0);
  const [streak, setStreak] = useState(0);
  const [totalTime, setTotalTime] = useState(0);
  const [loading, setLoading] = useState(false);
  
  // 模拟用户ID（实际应用中应该从认证系统获取）
  const currentUserId = 1;

  // 提肛运动的节奏配置
  const exercisePhases = {
    contract: { duration: 3, text: '收缩', color: 'bg-red-500' },
    hold: { duration: 3, text: '保持', color: 'bg-yellow-500' },
    relax: { duration: 3, text: '放松', color: 'bg-green-500' }
  };

  const phaseOrder = ['contract', 'hold', 'relax'];

  // 加载用户统计数据
  useEffect(() => {
    loadUserStats();
  }, []);

  const loadUserStats = async () => {
    try {
      setLoading(true);
      const response = await statsAPI.getUserStats(currentUserId);
      if (response.success) {
        const { user, today } = response.data;
        setTodayCount(today.daily_count || 0);
        setStreak(user.current_streak || 0);
        setTotalTime(user.total_time_minutes || 0);
      }
    } catch (error) {
      console.error('Failed to load user stats:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let interval;
    if (isExercising && currentPhase !== 'ready') {
      interval = setInterval(() => {
        setTimer(prev => {
          const currentPhaseDuration = exercisePhases[currentPhase].duration;
          if (prev >= currentPhaseDuration) {
            // 切换到下一个阶段
            const currentIndex = phaseOrder.indexOf(currentPhase);
            const nextIndex = (currentIndex + 1) % phaseOrder.length;
            setCurrentPhase(phaseOrder[nextIndex]);
            
            // 如果完成一个完整循环，记录到后端
            if (nextIndex === 0) {
              recordExerciseToBackend();
            }
            
            return 0;
          }
          return prev + 0.1;
        });
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isExercising, currentPhase]);

  const recordExerciseToBackend = async () => {
    try {
      const exerciseData = {
        user_id: currentUserId,
        duration_seconds: 9, // 一个完整循环9秒
        repetitions: 1,
        phase_type: 'complete_cycle'
      };
      
      const response = await exerciseAPI.recordExercise(exerciseData);
      if (response.success) {
        // 更新本地状态
        setTodayCount(prev => prev + 1);
        setTotalTime(prev => prev + 1); // 增加1分钟（简化计算）
        
        // 重新加载统计数据以获取最新的连续天数
        loadUserStats();
      }
    } catch (error) {
      console.error('Failed to record exercise:', error);
    }
  };

  const startExercise = () => {
    setIsExercising(true);
    setCurrentPhase('contract');
    setTimer(0);
  };

  const pauseExercise = () => {
    setIsExercising(false);
  };

  const resetExercise = () => {
    setIsExercising(false);
    setCurrentPhase('ready');
    setTimer(0);
  };

  const getButtonText = () => {
    if (currentPhase === 'ready') return '开始提肛';
    if (!isExercising) return '继续';
    return exercisePhases[currentPhase]?.text || '提肛中';
  };

  const getProgressPercentage = () => {
    if (currentPhase === 'ready') return 0;
    const duration = exercisePhases[currentPhase]?.duration || 1;
    return (timer / duration) * 100;
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center space-y-8 p-8">
        <div className="loading-spinner"></div>
        <p className="text-gray-500">加载中...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center space-y-8 p-8">
      {/* 统计信息 */}
      <div className="grid grid-cols-3 gap-6 w-full max-w-md">
        <div className="text-center">
          <div className="text-2xl font-bold text-gradient">{todayCount}</div>
          <div className="text-sm text-gray-500">今日完成</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-gradient">{streak}</div>
          <div className="text-sm text-gray-500">连续天数</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-gradient">{Math.floor(totalTime / 60)}</div>
          <div className="text-sm text-gray-500">总时长(分)</div>
        </div>
      </div>

      {/* 主按钮区域 */}
      <div className="relative">
        {/* 进度环 */}
        <div className="absolute inset-0 w-48 h-48">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="45"
              stroke="rgba(129, 216, 207, 0.2)"
              strokeWidth="3"
              fill="none"
            />
            <circle
              cx="50"
              cy="50"
              r="45"
              stroke="var(--tiffany-blue)"
              strokeWidth="3"
              fill="none"
              strokeDasharray={`${2 * Math.PI * 45}`}
              strokeDashoffset={`${2 * Math.PI * 45 * (1 - getProgressPercentage() / 100)}`}
              className="transition-all duration-100 ease-linear"
            />
          </svg>
        </div>

        {/* 主按钮 */}
        <button
          onClick={currentPhase === 'ready' ? startExercise : (isExercising ? pauseExercise : startExercise)}
          className={`
            tigang-button ripple-effect w-48 h-48 rounded-full
            flex flex-col items-center justify-center
            ${isExercising ? 'pulse-animation' : ''}
            ${currentPhase !== 'ready' ? exercisePhases[currentPhase]?.color : ''}
          `}
        >
          <div className="text-2xl font-bold mb-2">
            {getButtonText()}
          </div>
          {currentPhase !== 'ready' && (
            <div className="text-sm opacity-80">
              {(exercisePhases[currentPhase]?.duration - timer).toFixed(1)}s
            </div>
          )}
        </button>
      </div>

      {/* 控制按钮 */}
      <div className="flex items-center space-x-4">
        <Button
          variant="outline"
          size="sm"
          onClick={isExercising ? pauseExercise : startExercise}
          disabled={currentPhase === 'ready'}
          className="flex items-center space-x-2"
        >
          {isExercising ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          <span>{isExercising ? '暂停' : '继续'}</span>
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={resetExercise}
          disabled={currentPhase === 'ready'}
          className="flex items-center space-x-2"
        >
          <RotateCcw className="w-4 h-4" />
          <span>重置</span>
        </Button>
      </div>

      {/* 运动指导 */}
      <div className="text-center max-w-md">
        <h3 className="text-lg font-semibold mb-2">运动指导</h3>
        <div className="text-sm text-gray-600 space-y-1">
          <p><span className="text-red-500 font-medium">收缩：</span>收紧肛门肌肉，向上提升</p>
          <p><span className="text-yellow-500 font-medium">保持：</span>维持收缩状态，保持呼吸</p>
          <p><span className="text-green-500 font-medium">放松：</span>缓慢放松肌肉，自然呼吸</p>
        </div>
      </div>

      {/* 今日目标 */}
      <div className="w-full max-w-md">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-gray-600">今日目标</span>
          <span className="text-sm text-gray-600">{todayCount}/20</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="tigang-gradient h-2 rounded-full transition-all duration-300"
            style={{ width: `${Math.min((todayCount / 20) * 100, 100)}%` }}
          ></div>
        </div>
        {todayCount >= 20 && (
          <div className="text-center mt-2">
            <span className="text-green-600 font-medium">🎉 今日目标已达成！</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default TigangButton;

